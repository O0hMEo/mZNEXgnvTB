<?php
namespace App\Models;

class Nieuws {
    public int $id;
    public string $kop;
    public string $date;
    public string $text;
}
