<?php
namespace App\Models;

class Speler {
    public $id;
    public $voornaam;
    public $achternaam;
    public $geboortedatum;
    public $team;
}
