<?php
namespace App\Models;

class Wedstrijd {
    public $id;
    public $team1;
    public $team2;
    public $schijdsrechter1;
    public $schijdsrechter2;
    public $tafel1;
    public $tafel2;
    public $datum;
}
