<?php
namespace App\Models;

class Programma {
    public $id;
    public $beginTijd;
    public $eindTijd;
    public $dag;
    public $team;
    public $locatie;
}